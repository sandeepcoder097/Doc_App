list = []
a = int(input("Enter number of synterms(at least 3):"))
for i  in range(0,a):
    ab = input()
    list.append(ab)
print(list)
hypertensive_disease = ['pain chest',
              'shortness of breath',
              'dizziness',
              'asthenia',
              'fall',
              'syncope',
              'vertigo',
              'sweat',
              'sweating increased','palpitation','nausea','angina pectoris','pressure chest']
diabetes = ['polyuria',
              'polydypsia',
              'shortness of breath',
              'pain chest',
              'asthenia',
              'nausea',
              'orthopnea',
              'rale',
              'sweat',
              'sweating increased',
              'unresponsiveness',
              'mental status changes',
              'vertigo',
              'vomiting',
              'labored breathing']
c1 = 0
c2 = 0
for item in list:
    if item in diabetes:
       c1 = c1+1 
for item in list:
    if item in hypertensive_disease:
       c2 = c2+1 
if(c1>c2):
    print("hypertensive_disease")
elif(c2>c1):
    print("diabetes")
elif(c1==c2):
    print("You have either hypertensive_disease or diabetes please cunsult with doctor")
print(c1,c2)
    
